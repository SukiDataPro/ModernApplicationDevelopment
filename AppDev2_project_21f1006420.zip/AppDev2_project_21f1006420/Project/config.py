class Config(object):
    SQLALCHEMY_DATABASE_URI = 'sqlite:///test.db'
    SECRET_KEY = "sukisecretkey"
    SECURITY_PASSWORD_SALT = "sukisaltpassword"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = False
    SECURITY_TOKEN_AUTHENTICATION_HEADER = 'Authentication-Token'
    CACHE_TYPE = "RedisCache"
    CACHE_REDIS_HOST = "localhost"
    CACHE_REDIS_PORT = 6379
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 465
    MAIL_USE_SSL = True
    MAIL_USERNAME = 'test21f1006420@gmail.com'
    MAIL_PASSWORD = 'lwfbydpkzdclshpp'
    MAIL_DEFAULT_SENDER = 'test21f1006420@gmail.com'
    MAIL_DEBUG = True

class DevelopmentConfig(Config):
    DEBUG = True
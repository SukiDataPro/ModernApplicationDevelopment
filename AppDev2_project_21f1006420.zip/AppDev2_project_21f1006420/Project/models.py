from flask_sqlalchemy import SQLAlchemy
from flask_security import UserMixin,RoleMixin

db = SQLAlchemy()

class Venue(db.Model):
	venue_id = db.Column(db.Integer, primary_key = True)
	venue_name =  db.Column(db.String, nullable=False, unique=True)
	venue_place =  db.Column(db.String, nullable=False)
	venue_location =  db.Column(db.String, nullable=False)
	venue_capacity =  db.Column(db.Integer, nullable=False)
	shows = db.relationship("Show", secondary="association", backref="venues")

class Show(db.Model):
	show_id = db.Column(db.Integer, primary_key = True)
	show_name =  db.Column(db.String, nullable=False)
	show_rating =  db.Column(db.String, nullable=False)
	show_timing  = db.Column(db.String, nullable=False)
	show_tags =  db.Column(db.String, nullable=False)
	show_price =  db.Column(db.Integer, nullable=False)
	uix_1 = db.UniqueConstraint('show_id','show_name','show_timing')

class Tickets(db.Model):
	venue_id = db.Column(db.Integer, primary_key = True)
	show_id = db.Column(db.Integer, primary_key = True)
	ven_capacity =  db.Column(db.Integer, nullable=False)
	seats_booked =  db.Column(db.Integer, nullable=False, default=0)
	avail_seats =  db.column_property(ven_capacity - seats_booked)

class Association(db.Model):
	venue_id = db.Column(db.Integer, db.ForeignKey("venue.venue_id"), primary_key=True)
	show_id = db.Column(db.Integer, db.ForeignKey("show.show_id"), primary_key=True)

class User(db.Model,UserMixin):
	user_id = db.Column(db.Integer, primary_key = True)
	user_name = db.Column(db.String,nullable=False, unique = True)
	email = db.Column(db.String, unique=True)
	password = db.Column(db.String,nullable=False)
	active = db.Column(db.Boolean())
	fs_uniquifier = db.Column(db.String, unique=True,nullable=False)
	roles = db.relationship('Role', secondary='roles_users',backref='user1')

class Customer(db.Model):
	cust_id = db.Column(db.Integer, primary_key = True)
	cust_name = db.Column(db.String,nullable=False, unique = True)
	cust_email = db.Column(db.String, unique=True)
	cust_password = db.Column(db.String,nullable=False)
	last_visit_date = db.Column(db.DateTime)
	bookings = db.relationship("Show",secondary="booking",backref="customers")

class Booking(db.Model):
	cust_id = db.Column(db.Integer, db.ForeignKey("customer.cust_id"), primary_key = True)
	show_id = db.Column(db.Integer, db.ForeignKey("show.show_id"), primary_key=True)
	
class Role(db.Model,RoleMixin):
	role_id = db.Column(db.Integer, primary_key = True)
	role_name = db.Column(db.String, unique=True)
	description = db.Column(db.String)
	
class roles_users(db.Model):
	user_id = db.Column(db.Integer, db.ForeignKey("user.user_id"), primary_key = True)
	role_id = db.Column(db.Integer, db.ForeignKey("role.role_id"), primary_key=True)

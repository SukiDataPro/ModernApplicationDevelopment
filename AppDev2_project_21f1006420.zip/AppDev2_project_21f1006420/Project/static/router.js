import Profile from './component/Profile.js'
import Home from './component/Home.js'
import AdminLogin from './component/AdminLogin.js'
import UserLogin from './component/UserLogin.js'
import Adashboard from './component/Adashboard.js'
import ManageShow from './component/ManageShow.js'
import Addshow from './component/Addshow.js'
import Signup from './component/Signup.js'
import Udashboard from './component/Udashboard.js'
import Venuedetails from './component/Venuedetails.js'
import Booklist from './component/Booklist.js'


const routes = [
    { path: '/', component: Home },
    { path: '/profile', component: Profile },
    { path: '/adashboard', component: Adashboard },
    { path: '/manageshow/', component: ManageShow },
    { path: '/signup', component: Signup },   
    { path: '/udashboard', component: Udashboard }, 
    { path: '/booklist', component: Booklist },   
    { path: '/addshow/:id', component: Addshow },
    { path: '/venuedetails/:id', component: Venuedetails },
    { name: "Admin", path: '/admin', component: AdminLogin },
    { name: "User", path: '/user', component: UserLogin },
]

const router = new VueRouter({
    routes,
})

export default router
export default {
    template: `<div> <center> Welcome to Movie time application </center>
                <div>
                <p> Entertainment website </p> 
                <p> Join in our birthday celebrations & grab super epic discounts on every booking 🥂 #HappyHour starts at 5 pm sharp </p>
                </div>
             </div>`,
    mounted() {
        fetch('http://localhost:8080/profile', {
            headers: {
                'Authentication-Token': localStorage.getItem('auth-token'),
            },
        })
        .then((res) => {
            console.log(res.statusText)
            return res.json()
        })
        .then((data) => {
            console.log(data)
        })
    },
}
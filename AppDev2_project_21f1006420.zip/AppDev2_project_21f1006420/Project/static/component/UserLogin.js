export default {
    template: `<div>
                    <h1> User Login </h1>
                        <section class="vh-100">
                            <div class="container-fluid h-custom">
                                <div class="row d-flex justify-content-center align-items-center h-100">
                                <div class="col-md-9 col-lg-6 col-xl-5">
                                    <img src="static/profile.jpg" class="img-fluid"
                                    alt="Sample image">
                                </div>
                                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                                    <form>
                                    <div>
                                        <h5 style="color:Red;"> {{ message }} </h5>
                                    </div>
                                    <div class="d-flex flex-row align-items-center justify-content-center justify-content-lg-start">
                                        <p class="lead fw-normal mb-0 me-3">Sign in with the user credentials</p>
                                    </div>

                                    <!-- Email input -->
                                    <div class="form-outline mb-4 my-4">
                                        <label class="form-label" for="useremail">Email address</label>
                                        <input type="email" v-model='email' id="useremail" class="form-control form-control-lg"
                                        placeholder="Enter a valid email address" />
                                    </div>

                                    <!-- Password input -->
                                    <div class="form-outline mb-3 my-4">
                                        <label class="form-label" for="userpassword">Password</label>
                                        <input type="password" v-model='password' id="userpassword" class="form-control form-control-lg"
                                        placeholder="Enter password" />
                                    </div>

                                    <div class="d-flex justify-content-between align-items-center">
                                        <a href="#!" class="text-body">Forgot password?</a>
                                    </div>

                                    <div class="text-center text-lg-start mt-4 pt-2 my-3">
                                        <button type="button" @click='userlogin' class="btn btn-primary btn-lg"
                                        style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button>
                                        <p class="small fw-bold mt-2 pt-1 mb-0 my-10">Don't have an account?
                                        <button class="link-danger" @click='signup'> Register </button> </p>
                                    </div>
                                    </form>
                                </div>
                                </div>
                            </div>
                        </section>
               </div>`,
     mounted: function() {
            document.title = "User Login"
    },
    data()  {
        return{
            email: null,
            password: null,
            message: "",
        }
    },
    methods: {
        signup : function() {
            this.$router.push("/signup")
    },
        userlogin: function() {
            const data = { email: this.email,
                           password: this.password,
                           message: this.message,
              };
            fetch('/userlogin',{
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
            .then((response)=> response.json())
            .then((data)=> {
                console.log("Success:" , data);
                this.message = data.message
                if (this.message != ""){
                   console.log("invalid credentials") 
                }
                else {
                    this.$router.push('/udashboard')
                }
            })
            .catch((error) => {
                console.error("Error:",error);
            });
        }
    },
    
}
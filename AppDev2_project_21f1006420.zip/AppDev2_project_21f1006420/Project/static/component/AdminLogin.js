export default {
    template: `<div>
                    <h1> Admin Login </h1>
                    <div class="bg-light">
                        <div class="container mt-5">
                            <div class="row justify-content-center">
                                <div class="col-md-6">
                                    <h1 class="text-center">Admin Login</h1>
                                    <p class="text-center">Please enter the admin login credentials</p>
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Email" v-model='email'><br>
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password" v-model='password'><br>
                                    </div>
                                    <div class="text-center">
                                        <button class="btn btn-primary" @click='login'>Login</button>
                                    </div>
                                    <div v-if="errorMessage" class="text-center mt-3 text-danger">
                                        {{ errorMessage }}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
               </div>`,
    data()  {
        return{
            email: null,
            password: null,
            errorMessage: '',
        }
    },
    methods: {
        login(){
            fetch('/login?include_auth_token',{
                method: 'POST',
                body: JSON.stringify({email: this.email, password: this.password}),
                headers: {
                    'Content-Type': 'application/json',
                },
            })
                .then((res)=> {
                    if (res.ok) {
                      return res.json()
                    } else {
                        throw new Error('Login credentials incorrect');
                    }
                })
                .then((data) => {
                     localStorage.setItem(
                        'auth-token',
                         data.response.user.authentication_token
                     )
                     this.$router.push('/adashboard')
                })
                .catch(error => {
                    this.errorMessage = error.message;
                });
        },
    },
}
export default {
    template: `<div class = "bg-info min-vh-100 d-flex flex-column align-items-center p-4">
                <h1 class="text-center mb-4"> Movie Time Application - User Dashboard </h1><br> <br> 
                <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
                    <div class="container-fluid mx-3">
                    <div class="input-group">
                        <input type="search" v-model=searchtext class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                        <button type="button" class="btn btn-outline-light" @click="search">search</button>
                    </div>
                    </div>
                </nav>
                <div class = "row">
                    <div class="card my-3 mx-3 col-3" style="width: 20rem;" v-for="show in shows" :key="show.show_id">
                        <div class="card-body">
                            <h5 class="card-title">Show name: {{ show.show_name }}</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Show rating: {{ show.show_rating }} </h6>
                            <p class="card-text">Show timing: {{show.show_timing}}</p>
                            <p class="card-text">Show tags: {{show.show_tags}}</p>
                            <p class="card-text">Ticket price: {{show.show_price}}</p>
                            <button @click="venuedetails(show.show_id)" class="btn btn-primary">Theatre details </button>
                        </div>
                    </div>
                </div>
            </div>`,
    mounted: function() {
        document.title = "Show Details"
        fetch("/show_list").then(response => response.json()).then(shows => {
            console.log("data returned from backend:", shows)
            this.shows = shows
        })
    },
    data: function() {
        return {
          shows : [],
          show_name : "",
          show_timing : "",
          show_rating : "",
          show_tags : "",
          show_price : "",
          searchtext : "",
        }
      },
    methods : {  
        venuedetails : function(id) {
            this.$router.push(`/venuedetails/${id}`)
        },
        search : function() {
            const data = { searchtext: this.searchtext };
            fetch("/search",{
                method: "POST",
                headers: { 
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            })
            .then((response)=> response.json())
            .then((data)=> {
                console.log("Success:" , data);
                this.shows = data;
                })
            .catch((error) => {
                console.error("Error:",error);
            });
        }
    },
}
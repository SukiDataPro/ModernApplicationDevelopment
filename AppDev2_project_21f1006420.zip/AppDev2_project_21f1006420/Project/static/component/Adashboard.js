export default {
  template: `<div> 
                <h1><center> Movie Time Application - Admin Dashboard </center> </h1><br> <br> 
                <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid mx-3 navbar-light bg-light">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item mx-3">
                        <div>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" id="create" data-bs-target="#staticBackdrop1">
                        Create Venue
                        </button>
                        <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Enter the venue details to create</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div>
                                            <label>Venue name : </label>
                                            <input v-model = venue_name type="text" name="venuename"> <br> <br>
                                        </div>
                                        <div>
                                            <label>Place : </label>
                                            <input v-model = venue_place type="text" name="place"><br><br>
                                        </div>
                                        <div>
                                            <label>Location : </label>
                                            <input v-model = venue_location type="text" name="location"><br><br>
                                        </div>
                                        <div>
                                            <label>Capacity : </label>
                                            <input v-model = venue_capacity type="text" name="capacity"><br><br><br>	
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" @click = "createvenue" class="btn btn-primary" data-bs-dismiss="modal">Create</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                        </li>
                        <div v-if="venues.length > 0">
                            <li class="nav-item mx-3">
                                <router-link to='/manageshow'> Manage show </router-link>
                            </li>
                        </div>
                    </ul>   
                    </div>
                </div>
                </nav>
                <router-view></router-view>
                <div v-if="venues.length === 0" class="text-center mt-3 text-info">
                    There are no theatre details to display. Click on 'Create Venue' to add new theatres and its details
                </div>
                <div v-else>
                <div class = "row">
                    <div class="card my-3 mx-3 col-3" style="width: 20rem;" v-for="venue in venues">
                        <div class="card-body">
                            <h5 class="card-title">Theatre name: {{ venue.venue_name }}</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Place: {{ venue.venue_place }} </h6>
                            <p class="card-text">Location: {{venue.venue_location}}</p>
                            <p class="card-text">Capacity: {{venue.venue_capacity}}</p>
                            <!-- Button trigger modal -->
                                <button type="button" class="card-link" :data-bs-target="'#staticBackdrop' + venue.venue_id" data-bs-toggle="modal">
                                    Edit 
                                </button>
                                <!-- Modal -->
                                <div class="modal fade" :id="'staticBackdrop' + venue.venue_id" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="'staticBackdropLabel' + venue.venue_id" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h1 class="modal-title fs-5" :id="'staticBackdropLabel' + venue.venue_id">Update Venue</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div>
                                                    <label>Venue name : </label>
                                                    <input v-model = "venue_name" type="text" name="venuename"> <br> <br>
                                                </div>
                                                <div>
                                                    <label>Place : </label>
                                                    <input v-model = venue_place type="text" name="place"><br><br>
                                                </div>
                                                <div>
                                                    <label>Location : </label>
                                                    <input v-model = venue_location type="text" name="location"><br><br>
                                                </div>
                                                <div>
                                                    <label>Capacity : </label>
                                                    <input v-model = venue_capacity type="text" name="capacity"><br><br><br>	
                                                </div>
                                            </div>
                                        <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" @click = "updatevenue(venue.venue_id)" class="btn btn-primary" data-bs-dismiss="modal">Edit Venue</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button @click="deletevenue(venue.venue_id)" class="card-link">Delete </button>
                        <button @click="addshow(venue.venue_id)" class="card-link">Movie details </button><br><br>

                        <button @click="trigger_celery_job(venue.venue_id)"> Download CSV </button>
                    </div>
                </div>
                </div>
            </div>
	        </div>`
                ,
  mounted: function() {
    document.title = "Admin Dashboard"
    fetch("/venue_list").then(response => response.json()).then(venues => {
        console.log("data returned from backend:", venues)
        this.venues = venues
    })
  },

  data: function() {
    return {
      venues : [],
      venue_id : "",
      venue_name : "",
      venue_place : "",
      venue_location : "",
      venue_capacity : "",
    }
  },

  methods : {
    deletevenue : function(id) {
        const confirmed = confirm("Are you sure you want to delete this venue?");
        if (!confirmed) {
            return; // If user cancels the confirmation, do nothing
        }
        fetch(`/deletevenue/${id}`).then(r => r.json()).then(d => {
            console.log("d");
            fetch("/venue_list").then(response => response.json()).then(venues => {
                console.log("data returned from backend:", venues)
                this.venues = venues
            })
        })
    },
    updatevenue : function(id) {
        const data = { venue_name: this.venue_name,
            venue_place: this.venue_place,
            venue_location: this.venue_location,
            venue_capacity: this.venue_capacity
          };
        fetch(`/updatevenue/${id}`,{
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
        .then((response)=> response.json())
        .then((data)=> {
            console.log("Success:" , data);
            fetch("/venue_list").then(response => response.json()).then(venues => {
                console.log("data returned from backend:", venues)
                this.venues = venues
            })
        })
        .catch((error) => {
            console.error("Error:",error);
        });
    },
    addshow : function(id) {
            this.$router.push(`/addshow/${id}`)
    },
    
    createvenue : function() {
        const data = { venue_name: this.venue_name,
                       venue_place: this.venue_place,
                       venue_location: this.venue_location,
                       venue_capacity: this.venue_capacity
                     };
        fetch("/createvenue",{
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
        .then((response)=> response.json())
        .then((data)=> {
            console.log("Success:" , data);
            fetch("/venue_list").then(response => response.json()).then(venues => {
                console.log("data returned from backend:", venues)
                this.venues = venues
            })
        })
        .catch((error) => {
            console.error("Error:",error);
        });

    },
    trigger_celery_job : function (id) {
        fetch(`trigger-celery-job/${id}`).then(r => r.json()
        ).then(d => {
            console.log("Celery task details:",d);
            

            setTimeout(() => {
                fetch(`/status/${d.Task_ID}`).then(r => r.json()
                ).then(d => {
                    if (d.Task_state === "SUCCESS"){
                        console.log("Task has finished the execution..")
                        window.location.href = `/download-file/${id}`;
                    }
                    else {
                        console.log("Task is still being executed...")
                    }   
                })
            }, 6000) 
        })
    }
  },
}

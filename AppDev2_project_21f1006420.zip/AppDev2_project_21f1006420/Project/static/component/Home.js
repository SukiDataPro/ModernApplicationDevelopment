export default {
    template: `<div> 
                    <h1 class="text-center mt-5">Welcome to MOVIE TIME application</h1>
                    <section class="vh-100">
                        <div class="container-fluid h-custom">
                            <div class="row d-flex justify-content-center align-items-center h-100">
                                <div class="col-md-9 col-lg-6 col-xl-5">
                                    <img src="static/profile.jpg" class="img-fluid" alt="Sample image">
                                </div>
                                <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                                    <p> Please select any one of the following </p>

                                    <div class="form-check">
                                        <input type="radio" id="admin" class="form-check-input" value="Admin" v-model="picked">
                                        <label class="form-check-label" for="admin">Admin</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="user" class="form-check-input" value="User" v-model="picked">
                                        <label class="form-check-label" for="user">User</label>
                                    </div>
                                </div>
                            </div>
                    </div></section>
	            </div>`,
    mounted : function(){
        document.title = "Home"
    },
    data() {
        return {
            picked: null,
        }
    },
methods: {
},
watch: {
        picked: function(val,oldval) {
                this.$router.push(`/${ val }`);
                }
        }
}

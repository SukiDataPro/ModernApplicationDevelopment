export default {
    template: `<div> 
                    <h1><center> Customer booking details </center> </h1><br> <br>    
                    <div class = "row">
                    <div class="card my-3 mx-3 col-3" style="width: 20rem;" v-for="show in booking_lists">
                        <div class="card-body">
                            <h5 class="card-title">Show name: {{ show.show_name }}</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Show rating: {{ show.show_rating }} </h6>
                            <p class="card-text">Show timing: {{show.show_timing}}</p>
                            <p class="card-text">Show tags: {{show.show_tags}}</p>
                        </div>
                    </div>
                </div>        
                <button @click="back" class="card-link">Previous page </button>           
    </div>`,

    mounted: function()
    {
      document.title = "Customer booking details"
      fetch("/booklist").then(response => response.json()).then(booking_lists => {
          console.log("data returned from backend:", booking_lists)
          this.booking_lists = booking_lists
      })
    },
  
    data: function() {
      return {
        booking_lists :[],
        show_name : "",
        show_timing : "",
        show_rating : "",
        show_tags : "",
        venue_name : "",
        venue_location : "",
        }
    },
    methods : {
        back : function() {
            this.$router.go(-1)
          },  
    },
}   

export default {
    template: `<div class = "bg-info min-vh-100 d-flex flex-column align-items-center p-4"> 
                  <h1 class="text-center mb-4"> Venue details for show : {{ sh_id }} </h1><br> <br> 
                  <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
                    <div class="container-fluid mx-3 navbar-light bg-light">
                    <div class="input-group">
                        <input type="search" v-model=searchtext class="form-control rounded" placeholder="Search" aria-label="Search" aria-describedby="search-addon" />
                        <button type="button" class="btn btn-outline-primary" @click="search1">search</button>
                    </div>
                    </div>
                </nav>
                    <div class = "row">
                        <div class="card my-3 mx-3 col-3" style="width: 20rem;" v-for="venue in venue1">
                          <div class="card-body">
                            <h5 class="card-title">Theatre name: {{ venue.venue_name }}</h5>
                            <h6 class="card-subtitle mb-2 text-body-secondary">Place: {{ venue.venue_place }} </h6>
                            <p class="card-text">Location: {{venue.venue_location}}</p>
                            <p class="card-text">Capacity: {{venue.venue_capacity}}</p>
                            <p class="card-text">Number of available tickets: {{venue.avail_seats}}</p> 
                            <div v-if = "venue.avail_seats < '1'">
                              <p style="color:Red;"> House full </p>
                            </div>
                            <div v-else>
                              <!-- Button trigger modal -->
                              <button type="button" class="card-link" :data-bs-target="'#staticBackdrop10' + venue.venue_id + sh_id" data-bs-toggle="modal">
                                Book Show
                              </button>
                                    <!-- Modal -->
                                    <div class="modal fade" :id="'staticBackdrop10' + venue.venue_id + sh_id" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="'staticBackdropLabel' + venue.venue_id + sh_id" aria-hidden="true">
                                      <div class="modal-dialog">
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <h1 class="modal-title fs-5" :id="'staticBackdropLabel' + venue.venue_id + sh_id">Book show: {{venue.venue_id}}</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                          </div>
                                          <div class="modal-body">
                                            <div>
                                              <h5 style="color:Red;"> {{ error_msg }} </h5>
                                              <p> {{price}} </p>
                                            </div>
                                            <div>
                                              <label>Enter the number of tickets to book : </label>
                                              <input v-model = no_of_tickets type="text" name="notickets"> <br> <br>
                                            </div>
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <button type="button" @click = "bookshow(venue.venue_id,sh_id)" class="btn btn-primary" data-bs-dismiss="modal">Confirm Ticket</button>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>   
                            <button @click="back" class="card-link">Previous page </button>  
                </div>`
                  ,
    mounted: function()
    {
      document.title = "Venue details"
      const sh_id = this.$route.params.id;
      fetch(`/venuedetails/${sh_id}`).then(response => response.json()).then(venue1 => {
          console.log("data returned from backend:", venue1)
          this.venue1 = venue1
      })
    },
  
    data: function() {
      return {
        venue1 : [],
        venue_id : "",
        venue_name : "",
        venue_place : "",
        venue_location : "",
        venue_capacity : "",
        avail_seats : "",
        no_of_tickets : "",
        error_msg : "",
        price : "",
        searchtext : "",
        sh_id : this.$route.params.id,
      }
    },
  
    methods : {
      bookshow : function(ven_id,sh_id) {
        const data = { 
          no_of_tickets: this.no_of_tickets,
          error_msg: this.error_msg,
          price: this.price
          };
        fetch(`/bookshow/${ven_id}/${sh_id}`,{
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
        .then((response) => response.json())
        .then((data)=> {
            console.log("Success:" , data);
            this.error_msg = data.error_msg
            this.price = data.price
            if (data.error_msg != "") {
              console.log(this.error_msg);
              const modalId = 'staticBackdrop10' + ven_id + sh_id;
              const modal = new bootstrap.Modal(document.getElementById(modalId));
              modal.show();
            }
            else{
              console.log(data.price)
              this.$router.push("/booklist")
            }
        })
        .catch((error) => {
            console.error("Error:",error);
        });
        
    },
    search1: function() {
      const data = { searchtext: this.searchtext };
      const sh_id = this.sh_id; 
      fetch(`/venuedetails/${sh_id}`, {
          method: "POST",
          headers: {
              "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
      })
      .then(response => response.json())
      .then(venue1 => {
          console.log("Search results:", venue1);
          this.venue1 = venue1; 
      })
      .catch(error => {
          console.error("Error:", error);
      });
  },
  back : function() {
    this.$router.go(-1)
  },
  
    },
  }
  


export default {
    template: `<div> 
                    <h1><center> List of all the shows available </center> </h1><br> <br>
                    
                    <div v-if="shows.length === 0" class="text-center mt-3 text-info">
                        There are no shows created to display. Click 'Create show' to create new shows for the available venues
                    </div>
                    <div v-else> 
                    <div class = "row">
                        <div class="card my-3 mx-3 col-3" style="width: 20rem;" v-for="show in shows">
                            <div class="card-body">
                                <h5 class="card-title">Show name: {{ show.show_name }}</h5>
                                <h6 class="card-subtitle mb-2 text-body-secondary">Show rating: {{ show.show_rating }} </h6>
                                <p class="card-text">Show timing: {{show.show_timing}}</p>
                                <p class="card-text">Show tags: {{show.show_tags}}</p>
                                <p class="card-text">Ticket price: {{show.show_price}}</p>
                                <!-- Button trigger modal -->
                                    <button type="button" class="card-link" :data-bs-target="'#staticBackdrop' + show.show_id" data-bs-toggle="modal">
                                        Edit 
                                    </button>
                                    <!-- Modal -->
                                    <div class="modal fade" :id="'staticBackdrop' + show.show_id" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="'staticBackdropLabel' + show.show_id" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h1 class="modal-title fs-5" :id="'staticBackdropLabel' + show.show_id">Update show</h1>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div>
                                                        <label>Show name : </label>
                                                        <input v-model = show_name type="text" name="showname"> <br> <br>
                                                    </div>
                                                    <div>
                                                        <label>Rating : </label>
                                                        <input v-model = show_rating type="text" name="rating"><br><br>
                                                    </div>
                                                    <div>
                                                        <label>Timing : </label>
                                                        <input v-model = show_timing type="text" name="timing"><br><br>
                                                    </div>
                                                    <div>
                                                        <label>Tags </label>
                                                        <input v-model = show_tags type="text" name="showtags"><br><br><br>	
                                                    </div>
                                                    <div>
                                                        <label>Ticket price </label>
                                                        <input v-model = show_price type="text" name="showprice"><br><br><br>	
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                    <button type="button" @click = "updateshow(show.show_id)" class="btn btn-primary" data-bs-dismiss="modal">Edit Show</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <button @click="deleteshow(show.show_id)" class="card-link">Delete </button>
                            </div>
                        </div>
                    </div>
                    </div>
  
                    <div>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop5">
                        Create Show
                        </button>
                        <div class="modal fade" id="staticBackdrop5" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Enter the show details to create</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div>
                                            <label>Show name : </label>
                                            <input v-model = show_name type="text" name="showname"> <br> <br>
                                        </div>
                                        <div>
                                            <label>Rating : </label>
                                            <input v-model = show_rating type="text" name="rating"><br><br>
                                        </div>
                                        <div>
                                            <label>Timing : </label>
                                            <input v-model = show_timing type="text" name="timing"><br><br>
                                        </div>
                                        <div>
                                            <label>Tags : </label>
                                            <input v-model = show_tags type="text" name="showtags"><br><br><br>	
                                        </div>
                                        <div>
                                            <label>Ticket price : </label>
                                            <input v-model = show_price type="text" name="showprice"><br><br><br>	
                                        </div>
                                        <div>
                                            <label> Select the venues: </label>
                                            <select v-model="selected" multiple>
                                                <option v-for="venue in venues" :value="venue.venue_id">
                                                {{ venue.venue_name }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" @click = "createshow" class="btn btn-primary" data-bs-dismiss="modal">Create</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                  </div><br><br>
                  <div class="mt-3 text-center">
                        <router-link :to="'/adashboard/'" class="btn btn-secondary">
                            Back to Venue Dashboard
                        </router-link>
                    </div>
                </div>`
                  ,
    mounted: function() {
      document.title = "Show details"
      fetch("/show_list").then(response => response.json()).then(shows => {
          console.log("data returned from backend:", shows)
          this.shows = shows
      }),
      fetch("/venue_list").then(response => response.json()).then(venues => {
        console.log("venue returned from backend:", venues)
        this.venues = venues
    })
    },
  
    data: function() {
      return {
        shows : [],
        show_name : "",
        show_timing : "",
        show_rating : "",
        show_tags : "",
        show_price : "",
        venues : [],
        venue_name : "",
        venue_place : "",
        venue_location : "",
        venue_capacity : "",
        selected : [],
      }
    },
  
    methods : {
      deleteshow : function(id) {
        const confirmed = confirm("Are you certain you want to cancel this show? If anyone has already reserved tickets for this screening, please notify them.");
        if (!confirmed) {
            return; 
        }
        fetch(`/deleteshow/${id}`).then(r => r.json()).then(d => {
              console.log("d");
              fetch("/show_list").then(response => response.json()).then(shows => {
                console.log("data returned from backend:", shows)
                this.shows = shows
              })
        })
      },
      updateshow : function(id) {
          const data = { show_name: this.show_name,
              show_rating: this.show_rating,
              show_timing: this.show_timing,
              show_tags: this.show_tags,
              show_price: this.show_price
            };
          fetch(`/updateshow/${id}`,{
              method: "POST",
              headers: { 
                  "Content-Type": "application/json",
              },
              body: JSON.stringify(data),
          })
          .then((response)=> response.json())
          .then((data)=> {
              console.log("Success:" , data);
              fetch("/show_list").then(response => response.json()).then(shows => {
                console.log("data returned from backend:", shows)
                this.shows = shows
              })
          })
          .catch((error) => {
              console.error("Error:",error);
          });
      },
      createshow : function() {
        const data = { show_name: this.show_name,
            show_rating: this.show_rating,
            show_timing: this.show_timing,
            show_tags: this.show_tags,
            show_price: this.show_price,
            selected: this.selected,
            };
          fetch("/createshow",{
              method: "POST",
              headers: { 
                  "Content-Type": "application/json",
              },
              body: JSON.stringify(data),
          })
          .then((response)=> response.json())
          .then((data)=> {
              console.log("Success:" , data);
              fetch("/show_list").then(response => response.json()).then(shows => {
                console.log("data returned from backend:", shows)
                this.shows = shows
              })
          })
          .catch((error) => {
              console.error("Error:",error);
          });
  
      }
    },
  }
  


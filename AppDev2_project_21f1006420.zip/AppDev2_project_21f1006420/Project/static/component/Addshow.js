export default {
    template: `<div> 
                  <h1><center> Shows running in the Venue : {{ $route.params.id }} </center> </h1><br> <br> 
                  <div v-if="shows.length === 0" class="text-center mt-3 text-info">
                        There are no shows running in the current venue
                    </div>
                    <div v-else>
                    <div class = "row">
                        <div class="card my-3 mx-3 col-3" style="width: 20rem;" v-for="show in show1">
                            <div class="card-body">
                                <h5 class="card-title">Show name: {{ show.show_name }}</h5>
                                <h6 class="card-subtitle mb-2 text-body-secondary">Show rating: {{ show.show_rating }} </h6>
                                <p class="card-text">Show timing: {{show.show_timing}}</p>
                                <p class="card-text">Show tags: {{show.show_tags}}</p>
                                <p class="card-text">Ticket price: {{show.show_price}}</p>
                                <button @click="removeshow(show.show_id,this.ven_id)" class="card-link">Remove </button>
                            </div>
                        </div>
                    </div> 
                    </div> 
                    <div>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#staticBackdrop8">
                        Add Show
                        </button>
                        <div class="modal fade" id="staticBackdrop8" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Enter the show details to create</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        <div>
                                            <label> Select the shows you want to add: </label>
                                            <select v-model="selected" multiple>
                                                <option v-for="show in shows" :value="show.show_id">
                                                {{ show.show_name }}
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="button" @click = "addshow(this.ven_id)" class="btn btn-primary" data-bs-dismiss="modal">Add Show</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>   
                    <div class="mt-3 text-center">
                        <router-link :to="'/adashboard/'" class="btn btn-secondary">
                            Back to Venue Dashboard
                        </router-link>
                    </div>
                   
                </div>`
                  ,
    mounted: function()
    {
      document.title = "Show details"
      const ven_id = this.$route.params.id;
      fetch(`/show_details/${ven_id}`).then(response => response.json()).then(show1 => {
          console.log("data returned from backend:", show1)
          this.show1 = show1
      })
      fetch("/show_list").then(response => response.json()).then(shows => {
        console.log("data returned from backend:", shows)
        this.shows = shows
    })
    },
  
    data: function() {
      return {
        show1 : [],
        shows : [],
        selected : [],
        show_name : "",
        show_timing : "",
        show_rating : "",
        show_tags : "",
        show_price : "",
        ven_id : this.$route.params.id,
      }
    },
  
    methods : {
      removeshow : function(id,ven_id) {
        fetch(`/removeshow/${id}/${this.ven_id}`).then(r => r.json()).then(d => {
            console.log("d");
            fetch(`/show_details/${this.ven_id}`).then(response => response.json()).then(show1 => {
              console.log("data returned from backend:", show1)
              this.show1 = show1
            })
        })
    },
    addshow : function(ven_id) {
      const data = { 
        show_name: this.show_name,
        show_rating: this.show_rating,
        show_timing: this.show_timing,
        show_tags: this.show_tags,
        show_price: this.show_price,
        selected: this.selected,
        };
        fetch(`/addshow/${this.ven_id}`,{
            method: "POST",
            headers: { 
                "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
        })
        .then((response)=> response.json())
        .then((data)=> {
            console.log("Success:" , data);
            fetch(`/show_details/${this.ven_id}`).then(response => response.json()).then(show1 => {
              console.log("data returned from backend:", show1)
              this.show1 = show1
            })
        })
        .catch((error) => {
            console.error("Error:",error);
        });

    }
    },
  }
  


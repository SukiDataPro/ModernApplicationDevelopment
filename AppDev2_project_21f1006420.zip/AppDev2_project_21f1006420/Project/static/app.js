import router from './router.js'

new Vue({
    el: '#app',
    delimeters : ['${','}'],
    template: `<div> 
                <nav class="navbar navbar-expand-lg bg-body-tertiary">
                <div class="container-fluid mx-3 navbar-dark bg-dark">
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item mx-3">
                            <router-link to='/'> Home </router-link>
                        </li>
                        <li class="nav-item mx-3">
                            <router-link to='/profile'> Profile </router-link>
                        </li>
                    </ul>
                        <li class="nav-item mx-3">
                            <button @click='logout'>Logout </button>
                         </li>   
                    </div>
                </div>
                </nav>
                <router-view></router-view>
               </div>`,

    router,
    computed: {
        isLoggedIn() {
            // Check if the auth-token is present in localStorage
            return !!localStorage.getItem('auth-token');
        }
    },
    methods:{
        logout(){
            if (this.isLoggedIn) {
                localStorage.removeItem('auth-token')
                window.location.href = '/logout'
            } else {
                window.location.href = '/logout'
            }
        },
    },
});
from celery import Celery,Task
from celery.schedules import crontab

def make_celery(app):
    celery = Celery(
        "main",
        backend=app.config['RESULT_BACKEND'],
        broker=app.config['CELERY_BROKER_URL'],
        enable_utc = False,
        timezone = "Asia/Calcutta"
    )
    celery.conf.update(app.config)

    celery.conf.beat_schedule = {
    'send-daily-reminders': {
        'task': 'main.send_daily_reminders',
        'schedule': crontab(hour=14, minute=17), 
        },
    }

    celery.conf.beat_schedule = {
    'generate-report-every-month': {
        'task': 'main.generate_report',
        'schedule': crontab(day_of_month=1, hour=0, minute=0), 
        },
    }

    class ContextTask(celery.Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    celery.Task = ContextTask
    return celery
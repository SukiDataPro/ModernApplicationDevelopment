from flask import Flask, render_template,request,jsonify,session,send_file
import requests
from config import DevelopmentConfig
from models import db,Venue,Show,Tickets,Association,User,Booking,Role,roles_users,Customer
from sqlalchemy import or_,and_
from flask_security import Security,SQLAlchemyUserDatastore,auth_required
from celery_worker import make_celery
from celery.result import AsyncResult
from flask_caching import Cache
from datetime import datetime, timedelta
from flask_mail import Mail, Message
from jinja2 import Environment, FileSystemLoader

import time,csv,os
from time import perf_counter_ns

datastore = SQLAlchemyUserDatastore(db,User,Role)

app = Flask(__name__)

app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'test21f1006420@gmail.com'
app.config['MAIL_DEFAULT_SENDER'] = 'test21f1006420@gmail.com'
app.config['MAIL_PASSWORD'] = 'lwfbydpkzdclshpp'
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_DEBUG'] = True
mail = Mail(app)


app.config.from_object(DevelopmentConfig)
db.init_app(app)    
app.app_context().push()
security = Security(app,datastore)
cache = Cache(app)
app.app_context().push()

app.config.update(
    CELERY_BROKER_URL="redis://localhost:6379",
    RESULT_BACKEND="redis://localhost:6379"
    ),
celery = make_celery(app)

@cache.cached(timeout=10, key_prefix='get_all_venues')
def get_all_venues():
    venue_list = Venue.query.all()
    return venue_list

@cache.cached(timeout=10, key_prefix='get_all_shows')
def get_all_shows():
    show_list = Show.query.all()
    return show_list

@celery.task
def generate_report():
    users = Customer.query.all()
    current_month = datetime.now().strftime('%B %Y')
    for user in users:
        user_month = user.last_visit_date.strftime('%B %Y')
        if user_month == current_month:
            bookings_this_month = [
                booking for booking in user.bookings
                ]
        shows_seen = []
        
        for booking in bookings_this_month:
            shows_seen.append({
                'name': booking.show.show_name,
                'rating': booking.show.show_rating,
            })
            env = Environment(loader=FileSystemLoader('./templates'))
            template = env.get_template('monthly_report.html')

            html_content = template.render(user=user, month=user_month, bookings=bookings_this_month, shows_seen=shows_seen)
            filename = f'{user.cust_name}_{user_month}_report.html'

            with open(filename, 'w') as report_file:
                report_file.write(html_content)
            send_monthly_report.delay(user.cust_email, filename)

@celery.task
def send_monthly_report(to_email, filename):
    subject = "Monthly entertainment Report"
    body = "Hello,\n\nWe hope you've been enjoying our services. Here's your monthly report attached.\n\nBest regards,\nMovie Time Team"

    msg = Message(subject=subject, recipients=[to_email], body=body)
    with app.open_resource(filename) as report_file:
        msg.attach(filename, 'text/html', report_file.read())
        
    try:
        mail.send(msg)
        print(f"Monthly report email sent to {to_email}")
    except Exception as e:
        print(f"Error sending monthly report email to {to_email}: {e}")

@app.route("/trigger-celery-job/<int:id>")
def trigger_celery_job(id):
    a = generate_csv.apply_async(args=[id])
    return {
        "Task_ID" : a.id,
        "Task_state" : a.state,
        "Task_result": a.result
    }
        
@celery.task()
def generate_csv(venue_id):
    time.sleep(6)
    ven = Venue.query.get(venue_id)
    shows = ven.shows
    show_details = [{'id': show.show_id, 'name': show.show_name, 'rating': show.show_rating, 'tags': show.show_tags, 'timing': show.show_timing} for show in shows]
    csv_data = 'id,name,rating,tags,timing\n'
    for show in show_details:
        csv_data += f"{show['id']},{show['name']},{show['rating']},{show['tags']},{show['timing']}\n"

    csv_filepath =  os.path.abspath(f"static/Theatre_details_{ven.venue_name}.csv")

    with open(csv_filepath, 'w') as csv_file:
        csv_file.write(csv_data)

@app.route("/download-file/<int:venue_id>")
def download_file(venue_id):
    ven = Venue.query.get(venue_id)
    file_path = os.path.abspath(f"static/Theatre_details_{ven.venue_name}.csv")   
    return send_file(file_path)

@app.route("/status/<id>")
def check_status(id):
    res = generate_csv.AsyncResult(id)
    return {
        "Task_ID" : res.id,
        "Task_state" : res.state,
        "Task_result": res.result
    }

@celery.task
def send_daily_reminders():
    yesterday = datetime.now() - timedelta(days=1)
    customers_to_remind = db.session.query(Customer).filter((Customer.last_visit_date <= yesterday) | (Customer.last_visit_date == None)).all()
    for customer in customers_to_remind:
        send_email_reminder(customer.cust_email)

def send_email_reminder(to_email):
    subject = "Reminder: Visit our Movie Time application"
    body = "Hello,\n\nWe hope to see you soon. Don't miss a chance to enjoy new movies and have a fun with your family!\n\nBest regards,\nMovie time Team"
       
    msg = Message(subject=subject, recipients=[to_email], body=body)
    try:    
        mail.send(msg)
        print(f"Reminder email sent to {to_email}")
    except Exception as e:
        print(f"Error sending reminder email to {to_email}: {e}")

@app.get('/')
def home():
    return render_template('index.html')


@app.get('/profile')
@auth_required('token') 
def profile():
    return jsonify({'name': 'User1'})

@app.post('/user')
def create_user():
    data = request.json
    datastore.create_user(**data)
    db.session.commit()
    return jsonify({'message': 'User created'})

@app.get('/manageshow/<id>')
def manage_show(id):
    return jsonify({'message':'show page'})

@app.route("/venue_list")
def venue_list():
    start = perf_counter_ns()
    venue_list = Venue.query.all()
    stop = perf_counter_ns()
    print('Time taken to fetch venue', stop - start)
    venues = []
    for i in venue_list:
        venues.append({
            'venue_id' : i.venue_id,
            'venue_name' : i.venue_name,
            'venue_place' : i.venue_place,
            'venue_location': i.venue_location,
            'venue_capacity': i.venue_capacity
        })
    return venues   

@app.route("/venuedetails/<id>", methods=['POST','GET'])
def venuedetails(id):
    if request.method == 'POST':
        data = request.get_json()
        searchtext = data.get("searchtext","") 
        venue_list = Venue.query.filter(and_(Venue.shows.any(show_id=id),Venue.venue_location.like('%' + searchtext + '%'))).all()
        venue1 = []
        for i in venue_list:
            t_obj = Tickets.query.filter_by(show_id=id,venue_id=i.venue_id).first()
            venue1.append({
                'venue_id' : i.venue_id,
                'venue_name' : i.venue_name,
                'venue_place' : i.venue_place,
                'venue_location': i.venue_location,
                'venue_capacity': i.venue_capacity,
                'avail_seats': t_obj.avail_seats
            })  
        return venue1 
    else:
        venue_list = Venue.query.filter(Venue.shows.any(show_id=id))
        venue1 = []
        for i in venue_list:
            t_obj = Tickets.query.filter_by(show_id=id,venue_id=i.venue_id).first()
            venue1.append({
                'venue_id' : i.venue_id,
                'venue_name' : i.venue_name,
                'venue_place' : i.venue_place,
                'venue_location': i.venue_location,
                'venue_capacity': i.venue_capacity,
                'avail_seats': t_obj.avail_seats
            })
        return venue1 


@app.route("/show_list")
def show_list():
    start = perf_counter_ns()
    show_list = Show.query.all()
    stop = perf_counter_ns()
    print('Time taken to fetch shows', stop - start)
    shows = []
    for i in show_list:
        shows.append({
            'show_id' : i.show_id,
            'show_name' : i.show_name,
            'show_rating' : i.show_rating,
            'show_timing':  i.show_timing,
            'show_tags': i.show_tags,
            'show_price': i.show_price
        })
    return shows

@app.route("/search", methods=['POST','GET'])
def search():
    data = request.get_json()
    searchtext = data.get("searchtext")
    show1 = Show.query.filter(or_(Show.show_name.like('%' + searchtext + '%'), Show.show_tags.like('%' + searchtext + '%'), Show.show_rating > searchtext)).all()
    shows = []
    for i in show1:
        shows.append({
            'show_id' : i.show_id,
            'show_name' : i.show_name,
            'show_rating' : i.show_rating,
            'show_timing':  i.show_timing,
            'show_tags': i.show_tags,
            'show_price': i.show_price
        })
    return shows

@app.route("/booklist")
def booklist():
    cust_email = session.get("cust_email",None)
    customer = Customer.query.filter_by(cust_email = cust_email).first()
    booking_lists = []

    for booking in customer.bookings:
        show_info = Show.query.get(booking.show_id)
        booking_lists.append({
            'show_id': show_info.show_id,
            'show_name': show_info.show_name,
            'show_rating': show_info.show_rating,
            'show_timing': show_info.show_timing,
            'show_tags': show_info.show_tags
            })
    return booking_lists

@app.route("/show_details/<data>")
def show_details(data):
    show_list = Show.query.filter(Show.venues.any(venue_id=data))
    show1 = []
    for i in show_list:
        show1.append({
            'show_id' : i.show_id,
            'show_name' : i.show_name,
            'show_rating' : i.show_rating,
            'show_timing':  i.show_timing,
            'show_tags': i.show_tags,
            'show_price': i.show_price
        })
    return show1

@app.route("/createshow", methods=['POST'])
def create_show():
    data = request.get_json()
    sh = Show(
			show_name = data.get("show_name",None),
			show_rating = data.get("show_rating",None),
			show_timing = data.get("show_timing",None),
			show_tags = data.get("show_tags",None),
            show_price = data.get("show_price",None),
			)
    db.session.add(sh)
    db.session.commit()
    for i in data.get("selected"):
        ven = Venue.query.get(i)
        t_obj = Tickets(
			venue_id = ven.venue_id,
			show_id = sh.show_id,
			ven_capacity = ven.venue_capacity
			)
        db.session.add(t_obj)
        sh.venues.append(ven)
        db.session.commit()
    return jsonify("show created")

@app.route("/addshow/<ven_id>", methods=['POST'])
def add_show(ven_id):
    data = request.get_json()
    ven = Venue.query.get(ven_id)
    for i in data.get("selected"):
        sh = Show.query.get(i)
        t_obj = Tickets(
			venue_id = ven.venue_id,
			show_id = sh.show_id,
			ven_capacity = ven.venue_capacity
			)
        db.session.add(t_obj)
        ven.shows.append(sh)
        db.session.commit()
    return jsonify("show added")

@app.route("/removeshow/<id>/<data>")
def removeshow(id,data):
    ven = Venue.query.get(data)
    sh = Show.query.get(id)
    t_obj = Tickets.query.filter_by(show_id=id,venue_id=data).first()
    db.session.delete(t_obj)
    ven.shows.clear(sh)
    db.session.commit()
    return jsonify("Show removed")

@app.route("/createvenue", methods=['POST'])
def create_venue():
    data = request.get_json()
    ven = Venue(
			venue_name = data.get("venue_name",None),
			venue_place = data.get("venue_place",None),
			venue_location = data.get("venue_location",None),
			venue_capacity = data.get("venue_capacity",None)
			)
    db.session.add(ven)
    db.session.commit()
    return jsonify("venue created")

@app.route("/deletevenue/<int:id>")
def deletevenue(id):
    print(id)
    ven = Venue.query.get(id)
    Tickets.query.filter_by(venue_id=id).delete()
    ven.shows.clear()
    db.session.delete(ven)
    db.session.commit()
    return jsonify("Venue deleted")

@app.route("/deleteshow/<int:id>")
def deleteshow(id):
    print(id)
    sh = Show.query.get(id)
   
    Tickets.query.filter_by(show_id=id).delete()
    sh.venues.clear()
    db.session.delete(sh)
    db.session.commit()
    return jsonify("Show deleted")

@app.route("/updatevenue/<id>", methods=['GET','POST'])
def updatevenue(id):
    data = request.get_json()
    ven = Venue.query.get(id)
    ven.venue_name = data.get("venue_name")
    ven.venue_place = data.get("venue_place")
    ven.venue_location = data.get("venue_location")
    ven.venue_capacity = data.get("venue_capacity")
    db.session.commit()
    return jsonify("Venue updated")

@app.post("/updateshow/<id>")
def updateshow(id):
    data = request.get_json()
    sh = Show.query.get(id)
    sh.show_name = data.get("show_name")
    sh.show_rating = data.get("show_rating")
    sh.show_timing = data.get("show_timing")
    sh.show_tags = data.get("show_tags")
    sh.show_price = data.get("show_price")
    db.session.commit()
    return jsonify("Show updated")

@app.route("/bookshow/<ven_id>/<sh_id>",methods=['GET','POST'])
def bookshow(ven_id,sh_id):
    cust_email = session.get("cust_email",None)
    data = request.get_json()
    no_of_tickets = data.get("no_of_tickets")
    session["bcount"] = no_of_tickets
    error_msg = ""
    Total_price = ""
    for value in Show.query.with_entities(Show.show_price).filter_by(show_id=sh_id).first():
        sh_price = value
    for value in Tickets.query.with_entities(Tickets.avail_seats).filter_by(show_id=sh_id,venue_id=ven_id).first():
        avail_seats = value
    for value in Tickets.query.with_entities(Tickets.seats_booked).filter_by(show_id=sh_id,venue_id=ven_id).first():
        seats_booked = value
    if int(no_of_tickets) > int(avail_seats):
        error_msg = "Enter the number of tickets based on available tickets"
        return jsonify({'error_msg':error_msg,'Total_price':Total_price})
    else:	
        error_msg=""
        Total_price = int(sh_price) * int(no_of_tickets) 
        Total_price = str(Total_price)
        t_obj = Tickets.query.filter_by(show_id=sh_id,venue_id=ven_id).first()
        t_obj.seats_booked = int(no_of_tickets) + int(seats_booked)
        db.session.commit()
        sh = Show.query.filter_by(show_id=sh_id).first()
        cust = Customer.query.filter_by(cust_email = cust_email).first()
        if sh not in cust.bookings:
            cust.bookings.append(sh)
            db.session.commit()
        return jsonify({'error_msg':error_msg,'Total_price':Total_price})

@app.route("/register", methods=['POST'])
def register():
    data = request.get_json()
    cust = Customer(
			cust_name = data.get("cust_name",None),
			cust_email = data.get("cust_email",None),
			cust_password = data.get("cust_pwd",None),
            last_visit_date=None,
			)
    db.session.add(cust)
    db.session.commit()
    return jsonify("customer created")

@app.route("/userlogin", methods=['GET','POST'])
def userlogin():
    data = request.get_json()
    message = ""
    valid = Customer.query.filter_by(cust_email = data.get("email"),cust_password = data.get("password")).first()
    if valid is not None:
        session["cust_email"]=data.get("email")
        valid.last_visit_date = datetime.now()
        db.session.commit()
    else:
        message = "Invalid credentials, please login with correct details"
    return jsonify ({'message':message})
    
if __name__ == '__main__':
    db.create_all()    
    app.run(debug=True,
            port=8080)